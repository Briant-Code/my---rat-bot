GROWBLOX LAUNCHER V2 - DELTA ANDROID
===================================

ISI FILE
- loader.lua                 : script lengkap, cukup satu file untuk GitHub Raw.
- Growblox_Launcher_V2.lua  : salinan sumber agar mudah dibaca dan diedit.
- Delta_GUI_Test.lua        : script pendek untuk menguji apakah Delta bisa menampilkan GUI.

CARA BUAT LINK LOADER TANPA PC
1. Buka github.com di Chrome, login.
2. Buat repository PUBLIC bernama GrowbloxLauncher (branch utama: main).
3. Buka repository, pilih Add file -> Upload files.
4. Unggah loader.lua. Commit changes ke branch main.
5. Buka file loader.lua -> Raw -> salin URL.
6. Contoh pola URL yang akan muncul:
   https://raw.githubusercontent.com/USERNAME/GrowbloxLauncher/main/loader.lua
7. Ganti USERNAME sesuai akun GitHub dan sesuaikan branch/nama repo jika berbeda.
8. Di Delta setelah masuk ke Growblox, tempel:
   loadstring(game:HttpGet("https://raw.githubusercontent.com/USERNAME/GrowbloxLauncher/main/loader.lua"))()

PENTING
- URL contoh BELUM online sebelum kamu mengunggah file sendiri ke GitHub.
- Jangan masukkan teks Markdown seperti [https://...](https://...) ke dalam tanda petik URL.
- Jika belum muncul apa-apa, jalankan isi Delta_GUI_Test.lua dulu.
- Jika tes berhasil tapi menu V2 gagal, buka console Delta dan catat pesan [Growblox V2].
- Menjalankan script langsung dengan paste full Lua di Delta juga mungkin; loadstring dipakai untuk mengambil file secara online, bukan syarat mutlak Delta.
- Fly/Noclip/Speed bergantung pada controller dan validasi server Growblox. Script ini tidak menyediakan akses admin, data server atau bypass proteksi.
