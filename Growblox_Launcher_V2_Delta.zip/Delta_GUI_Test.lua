-- Delta GUI Test: paste the full code in Delta to confirm LocalPlayer UI creation.
local ok, message = pcall(function()
    local players = game:GetService("Players")
    local p = players.LocalPlayer
    if not p then error("LocalPlayer belum ada, masuk game dahulu") end
    local pg = p:WaitForChild("PlayerGui", 10)
    if not pg then error("PlayerGui tidak tersedia") end
    local existing = pg:FindFirstChild("DeltaGrowbloxTest")
    if existing then existing:Destroy() end
    local ui = Instance.new("ScreenGui")
    ui.Name="DeltaGrowbloxTest"
    ui.ResetOnSpawn=false
    ui.DisplayOrder=200001
    ui.Parent=pg
    local label=Instance.new("TextLabel")
    label.Size=UDim2.fromOffset(230,60)
    label.Position=UDim2.new(0,20,0.15,0)
    label.BackgroundColor3=Color3.fromRGB(17,33,47)
    label.TextColor3=Color3.fromRGB(105,255,175)
    label.Font=Enum.Font.GothamBold
    label.TextSize=17
    label.Text="DELTA OK - UI BERHASIL"
    label.Parent=ui
    print("[Growblox Test] Delta berhasil membuat UI")
end)
if not ok then warn("[Growblox Test] " .. tostring(message)) end
